"use strict";
exports.id = 231;
exports.ids = [231];
exports.modules = {

/***/ 9231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_ListButiks)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/ImageLink.js
var ImageLink = __webpack_require__(823);
;// CONCATENATED MODULE: ./public/butiks/Бренды.png
/* harmony default export */ const _ = ({"src":"/_next/static/media/Бренды.031de335.png","height":547,"width":179,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAICAMAAAALMbVOAAAACVBMVEX6+vr39/f7+/ujmsnwAAAAA3RSTlMjGC6esKnxAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAHUlEQVR4nB3IsQ0AMBDEIM77D/1KOgQIG7WP7I1yAScAFJ8FJeIAAAAASUVORK5CYII=","blurWidth":3,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/ListButiks.js





//получаем данные со страниц бутиков и их категорию
const ListButiks = ({ butiks , category , butiksUrl  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-3 gap-y-12 justify-between items-center my-24 mr-32 ml-5",
        children: [
            butiks && butiks.filter((item)=>item.category === `${category}`) //*фильтруем по категории для отображения нужных на странице
            .map(({ id , logo , url  })=>/*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                    href: `/${butiksUrl}/${id}`,
                    src: logo,
                    width: 56,
                    alt: url
                }, id)),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: _,
                alt: "slide1",
                width: "0",
                height: "0",
                sizes: "100%",
                className: "absolute top-1/4 -right-5 w-1/12"
            })
        ]
    });
};
/* harmony default export */ const components_ListButiks = (ListButiks);


/***/ })

};
;