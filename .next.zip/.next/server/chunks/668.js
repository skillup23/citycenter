"use strict";
exports.id = 668;
exports.ids = [668];
exports.modules = {

/***/ 823:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




function ImageLink({ href , src , alt , width , cssClass  }) {
    const widthImg = width ? `w-${width}` : "w-56";
    const otherClass = cssClass ? `ease-in duration-200 hover:scale-105 ${cssClass}` : `ease-in duration-200 hover:scale-105`;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: href,
        className: widthImg,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: src,
            alt: alt,
            // width={width ? width : '300'}
            width: "0",
            height: "0",
            sizes: "100%",
            // className="ease-in duration-200 hover:scale-105"
            className: otherClass,
            style: {
                width: "auto",
                height: "auto"
            },
            priority: true
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageLink);


/***/ }),

/***/ 3668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/site_img/logo-nav.png
/* harmony default export */ const logo_nav = ({"src":"/_next/static/media/logo-nav.7b595e07.png","height":258,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAHlBMVEX+/v7///9MaXH////+/v7////////8/Pz////////8FeD3AAAACnRSTlM7VwCGSaUHdB0oiiDlQQAAAAlwSFlzAAAuIwAALiMBeKU/dgAAACRJREFUeJwFwYEBACAIw7CugOj/D5vgoSZHTE0tor25SsNL6A8HBwBgLmLqcQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/sl"
var sl_ = __webpack_require__(5065);
// EXTERNAL MODULE: ./public/data/data.js
var data = __webpack_require__(5743);
;// CONCATENATED MODULE: ./components/Header.js








function Header() {
    return /*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: "py-5 my-1 border_section z-50",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
            className: "container mx-auto px-5 flex justify-between content-center items-center",
            children: [
                data/* menu.slice */.GI.slice(0, 5).map(({ id , name , link  })=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: link,
                        scroll: false,
                        className: "text-3xl ease-in duration-200 hover:scale-105",
                        children: name
                    }, id);
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: logo_nav,
                        alt: "logo",
                        width: 150,
                        priority: true,
                        className: "ease-in duration-200 hover:scale-105"
                    })
                }),
                data/* menu.slice */.GI.slice(5, 8).map(({ id , name , link  })=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: link,
                        scroll: false,
                        className: "text-3xl ease-in duration-200 hover:scale-105 mr-5",
                        children: name
                    }, id);
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "flex gap-10",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "https://vk.com/trkcitycentr",
                            target: "_blank",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(sl_.SlSocialVkontakte, {
                                className: "text-4xl ease-in duration-200 hover:scale-105"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "https://t.me/ciiitycenter",
                            target: "_blank",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTelegramPlane, {
                                className: "text-4xl ease-in duration-200 hover:scale-105 mr-5"
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const components_Header = (Header);

;// CONCATENATED MODULE: ./public/site_img/logoBlack.png
/* harmony default export */ const logoBlack = ({"src":"/_next/static/media/logoBlack.103159b6.png","height":258,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAHlBMVEVMaXEDAwMEBAQDAwMFBQUBAQEAAAAEBAQGBgYICAh2bbxxAAAACnRSTlMAQlSNYaoHeTMf/cIdjAAAAAlwSFlzAAAOwwAADsMBx2+oZAAAACZJREFUeJwVxbkRACAQA7G1fQ/03zCDEsEoXQNUOisAb92fdGzpAQawAFnff6gwAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./components/Footer.js








function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "shrink-0 bg-white py-5 mt-16",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
            className: "container mx-auto flex justify-between items-center px-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: logoBlack,
                        alt: "Логотип",
                        width: "120",
                        height: "0",
                        sizes: "100%",
                        className: "ease-in duration-200 hover:scale-105"
                    })
                }),
                data/* menu.map */.GI.map(({ id , name , link  })=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: link,
                        className: "text-3xl ease-in duration-200 hover:scale-105 text-black",
                        children: name
                    }, id);
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex mr-3",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "https://vk.com/trkcitycentr",
                            target: "_blank",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(sl_.SlSocialVkontakte, {
                                className: "text-4xl ease-in duration-200 hover:scale-105 text-black mr-5"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "https://t.me/ciiitycenter",
                            target: "_blank",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTelegramPlane, {
                                className: "text-4xl ease-in duration-200 hover:scale-105 text-black"
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./public/site_img/phone-link.png
/* harmony default export */ const phone_link = ({"src":"/_next/static/media/phone-link.ef296b89.png","height":501,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAALVBMVEX////+/v78/Pz9/f1MaXGZmZjR0dH///+lpaT///+1tbRZWFh9fHu/vr5gX17iTaxYAAAACXRSTlMtr/frAP387P1X+JLsAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAOUlEQVR4nBXLSRLAIBDDQHk8QJks/39uwk2HFo2qRIOTxKCMnYqoXCdM5bnHjFGy3xnBOnhBI/vfPy6kAVbfsafQAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/mail-link.png
/* harmony default export */ const mail_link = ({"src":"/_next/static/media/mail-link.6a7bc499.png","height":501,"width":501,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAJ1BMVEX8/Pz9/f3+/v77+/vW1tZMaXH////9/f3////c3Ny+vb67urvLysuR0FfiAAAACHRSTlMs77D6+gDmqbptESoAAAAJcEhZcwAALiMAAC4jAXilP3YAAAA2SURBVHicRYsxDgAgCMQKCp7i/99rdHFr0pbAzZyAlKQEV5+za9Da2nspL1SV8ivsxgZvH8QBMJYBWY9QezEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/ikonka-event.png
/* harmony default export */ const ikonka_event = ({"src":"/_next/static/media/ikonka-event.f0ebb286.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAANlBMVEX////////c3Ny8vLz////////9/f3+/v5MaXH5+fn9/f12dnbQ0NDFxcX///+lpaWwsLDw8PACnRhDAAAADnRSTlPdlfz8H5vZHAD+lf76/iOptsQAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHicBcGJAcAgCATBRYlAnkP7bzYzZNxgkcRSlVZgGv28Mqje/Qk4u2cLTLN7yvB1xiic9Asuzx9IvwHqUs6JugAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./components/ImageLink.js
var ImageLink = __webpack_require__(823);
;// CONCATENATED MODULE: ./components/ButtonRight.js






function ButtonRight() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "fixed top-1/3 right-2 z-50 w-20",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                href: "tel:88612134705",
                src: phone_link,
                alt: "Телефон",
                width: 20,
                cssClass: ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                href: "mailto:info@citycenter.ru",
                src: mail_link,
                alt: "Почта",
                width: 20,
                cssClass: "mt-3"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                href: "/event_city",
                src: ikonka_event,
                alt: "События",
                width: 20,
                cssClass: "mt-3"
            })
        ]
    });
}
/* harmony default export */ const components_ButtonRight = (ButtonRight);

;// CONCATENATED MODULE: ./components/Layout.js






function Layout({ children , title  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "min-h-screen flex flex-col justify-start",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title ? title + ' - ТРК "СИТИ ЦЕНТР"' : 'ТРК "СИТИ ЦЕНТР"'
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Официальный сайт"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon-9.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "flex-auto",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_ButtonRight, {})
        ]
    });
}
/* harmony default export */ const components_Layout = (Layout);


/***/ }),

/***/ 5743:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GI": () => (/* binding */ menu),
/* harmony export */   "KI": () => (/* binding */ sliderCenter),
/* harmony export */   "un": () => (/* binding */ sliderTop)
/* harmony export */ });
const menu = [
    {
        id: 1,
        name: "Бутики",
        link: "/#bitiki"
    },
    {
        id: 2,
        name: "Рестораны",
        link: "/#restoran"
    },
    {
        id: 3,
        name: "Новости",
        link: "/news"
    },
    {
        id: 4,
        name: "Кинотеатр",
        link: "/#kinoteatr"
    },
    {
        id: 5,
        name: "Детям",
        link: "/#detyam"
    },
    {
        id: 6,
        name: "Сервисы",
        link: "/services"
    },
    {
        id: 7,
        name: "Контакты",
        link: "/contacts"
    },
    {
        id: 8,
        name: "Парковка",
        link: "/parking"
    }
];
const sliderTop = [
    {
        id: 1,
        src: "/slide_main/сайт_1-2022.jpg",
        alt: "Изображение 1"
    },
    {
        id: 2,
        src: "/slide_main/сайт_2-2022.jpg",
        alt: "Изображение 2"
    },
    {
        id: 3,
        src: "/slide_main/сайт_3-2022.jpg",
        alt: "Изображение 3"
    }
];
const sliderCenter = [
    {
        id: 1,
        src: "/slide_main/kino-banner-1.jpg",
        alt: "Кинобаннер 1"
    },
    {
        id: 2,
        src: "/slide_main/kino-banner-2.jpg",
        alt: "Кинобаннер 2"
    },
    {
        id: 3,
        src: "/slide_main/kino-banner-3.jpg",
        alt: "Кинобаннер 3"
    },
    {
        id: 4,
        src: "/slide_main/kino-banner-4.jpg",
        alt: "Кинобаннер 4"
    },
    {
        id: 5,
        src: "/slide_main/kino-banner-5.jpg",
        alt: "Кинобаннер 5"
    }
];



/***/ })

};
;