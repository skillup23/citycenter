"use strict";
exports.id = 733;
exports.ids = [733];
exports.modules = {

/***/ 6733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Butik)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./components/SliderBytik.js




const SliderBytik = ({ data , dots  })=>{
    const settings = {
        dots: dots,
        arrows: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 4000,
        appendDots: (dots)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    borderRadius: "10px",
                    padding: "10px"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    style: {
                        margin: "30px"
                    },
                    children: [
                        " ",
                        dots,
                        " "
                    ]
                })
            }),
        customPaging: ()=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    width: "5px",
                    height: "5px",
                    borderRadius: "50px",
                    backgroundColor: "#ddd"
                }
            })
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
            ...settings,
            children: data.map(({ id , src , alt  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "h-[70vh] relative overflow-hidden",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: src,
                        alt: alt,
                        fill: true,
                        // sizes="(max-width: 768px) 100vw,
                        // (max-width: 1200px) 100vw,
                        // 100vw"
                        className: "object-cover",
                        priority: true
                    })
                }, id))
        })
    });
};
/* harmony default export */ const components_SliderBytik = (SliderBytik);

// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: ./components/Layout.js + 8 modules
var Layout = __webpack_require__(3668);
;// CONCATENATED MODULE: ./components/Butik.js









function Butik(butik) {
    //используется для кнопки назад
    const router = (0,router_.useRouter)();
    //вытаскиваем данные из объекта
    const { url , logo , description1 , description2 , description3 , floor , tel , telUrl , instagram , image  } = butik.butik || {};
    //Если объекта нет, то указать что Бутика не существует и предложить вернуться назад
    if (!butik) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
            title: url,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "text-3xl text-center mt-20",
                    children: "Данного бутика не существует..."
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        type: "button",
                        className: "bg-white py-3 px-6 text-black m-auto mt-10 text-2xl",
                        onClick: ()=>router.back(),
                        children: "Вернуться назад"
                    })
                })
            ]
        });
    } else {
        //Возвращаем бутик
        return /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "mt-10",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto flex gap-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-1/2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_SliderBytik, {
                            data: image,
                            dots: true
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-1/2 flex flex-col justify-between items-start mr-8 pb-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: logo,
                                alt: url,
                                width: 200,
                                height: "0",
                                sizes: "100%",
                                className: "self-center"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xl text-justify tracking-wide",
                                        children: !description1 ? "Описание временно отсутствует" : `${description1}`
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xl text-justify tracking-wide mt-6",
                                        children: !description2 ? "" : `${description2}`
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xl text-justify tracking-wide mt-6",
                                        children: !description3 ? "" : `${description3}`
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-row w-fill items-center mt-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaMapMarkerAlt, {
                                                className: "text-3xl mr-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-2xl",
                                                children: floor
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-row w-fill items-center mt-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaPhoneAlt, {
                                                className: "text-2xl mr-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: telUrl,
                                                className: "text-2xl",
                                                children: tel
                                            })
                                        ]
                                    }),
                                    !instagram ? "" : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-row w-fill items-center mt-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsInstagram, {
                                                className: "text-3xl mr-5"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                href: `https://www.instagram.com/${instagram}`,
                                                target: "_blank",
                                                className: "text-2xl",
                                                children: [
                                                    "@",
                                                    instagram
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const components_Butik = (Butik);


/***/ })

};
;