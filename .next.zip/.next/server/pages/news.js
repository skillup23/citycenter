"use strict";
(() => {
var exports = {};
exports.id = 134;
exports.ids = [134];
exports.modules = {

/***/ 7834:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_news)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/Layout.js + 8 modules
var Layout = __webpack_require__(3668);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/news/1.jpg
/* harmony default export */ const _1 = ({"src":"/_next/static/media/1.fa273859.jpg","height":1000,"width":1000,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAcEAACAgIDAAAAAAAAAAAAAAABAgADBDERISL/xAAVAQEBAAAAAAAAAAAAAAAAAAADBP/EABgRAAIDAAAAAAAAAAAAAAAAAAABAhEh/9oADAMBAAIRAxEAPwCay7Lba7BWuOqtUqH0pJ4Gx3uIiSKVDvT/2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/news/2.jpg
/* harmony default export */ const _2 = ({"src":"/_next/static/media/2.bb3ad510.jpg","height":1024,"width":1024,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAT/xAAfEAABAwQDAQAAAAAAAAAAAAACAAEEAwURIQdBUXH/xAAUAQEAAAAAAAAAAAAAAAAAAAAD/8QAGBEBAAMBAAAAAAAAAAAAAAAAAQACESH/2gAMAwEAAhEDEQA/ALuQL7Jg2kY9MhEZLm1Q2y/Wm37v5hERHUHYjzJ//9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/news/3.jpg
/* harmony default export */ const _3 = ({"src":"/_next/static/media/3.9405f6b0.jpg","height":1024,"width":1024,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAgEAABAgUFAAAAAAAAAAAAAAABAAMCBAURIRIiMUGR/8QAFAEBAAAAAAAAAAAAAAAAAAAABf/EABkRAAIDAQAAAAAAAAAAAAAAAAECAAMhEf/aAAwDAQACEQMRAD8Ao06Vbp9bei3NMzbt3NMPAJwB2TfzKIiLDcirVqTmT//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/news/4.jpg
/* harmony default export */ const _4 = ({"src":"/_next/static/media/4.1ffd172a.jpg","height":1024,"width":1024,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAcEAACAQUBAAAAAAAAAAAAAAACAwABBAUREvH/xAAVAQEBAAAAAAAAAAAAAAAAAAADBP/EABcRAQEBAQAAAAAAAAAAAAAAAAEAEQL/2gAMAwEAAhEDEQA/AJcrimWxLyZdta1dB4Im759iIk5sjyYX/9k=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./pages/news/index.js









const news = [
    {
        id: 1,
        img: _1,
        title: [
            "\uD83D\uDD253000 бонусов от Эстель Адони\uD83D\uDD25"
        ],
        text: [
            {
                id: 1,
                t: "В новом сезоне продолжаем радовать Вас прекрасными новостями и подарками! Всем, кто совершил покупку в период летней распродажи, Эстель Адони дарит 3000 бонусов! Потратить их можно уже сегодня, до 16 октября 2022 года на товары из новых и базовых коллекций."
            },
            {
                id: 2,
                t1: "В бутик уже поступили роскошные новинки сезона от ваших любимых брендов!"
            },
            {
                id: 3,
                t1: "*Оплатить подарочными бонусами можно 20% от чека на новые и базовые коллекции!"
            }
        ]
    },
    {
        id: 2,
        img: _2,
        title: [
            "Бутик \xabДикая Орхидея\xbb дарит новогодние подарки✨"
        ],
        text: [
            {
                id: 1,
                t: "При покупке от 20.000 рублей дарим один из подарков: набор аксессуаров для волос из шелка, маску для сна из шелка или натуральную ароматическую свечу\uD83D\uDCAB"
            },
            {
                id: 2,
                t1: "Коллекции премиального женского белья \xabДикая Орхидея\xbb сшиты из высококачественных материалов и предоставляют возможность дома выглядеть элегантно и утонченно\uD83D\uDD4A️"
            }
        ]
    },
    {
        id: 3,
        img: _3,
        title: [
            "\uD83D\uDCA5Зимний SALE в \xabЭстель Адони\xbb\uD83D\uDCA5"
        ],
        text: [
            {
                id: 1,
                t: "Новый год начинается с хорошей новости! С 17 января в салоне \xabЭстель Адони\xbb стартует долгожданная зимняя распродажа. Вас ждут скидки до -40% на белье, купальники, одежду для дома, отдыха и пляжа!"
            },
            {
                id: 2,
                t1: "Для вас — любимые базовые комплекты на каждый день, эффектное кружево для особых случаев, натуральный хлопок для сна и потрясающий шелк для роскошного вечера."
            },
            {
                id: 3,
                t1: "Также порадуют вас приятными ценами купальники на любой вкус и тип фигуры, круизные коллекции платьев, сарафанов и туник, а также всевозможные аксессуары для путешествий мечты."
            }
        ]
    },
    {
        id: 4,
        img: _4,
        title: [
            "Весна – время расцвета и обновления!",
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}, 1),
            "В природе, душе и гардеробе!"
        ],
        text: [
            {
                id: 1,
                t: "Встречаем новинки весны в сочных оттенках красного, желтого, розового и голубого. Наряду с ними на модный олимп снова врывается белый. Стилисты рекомендуют этой весной непременно пополнить свою коллекцию белья кристально-белыми и ванильными комплектами."
            },
            {
                id: 2,
                t1: "Особенно трендовым становится белье с элементами прозрачности – как в комплектах для особого случая, так и на каждый день. Актуальна и вечная классика – цветочное кружево и изысканная вышивка."
            },
            {
                id: 3,
                t1: "Пляжные коллекции 2023 года наполнены вдохновляющими на путешествия оттенками моря, тропической зелени, ярких цветов и спелых фруктов. Для вас — купальники на одно плечо, бандо, мини-бикини для роскошного загара, а также множество платьев, туник и сарафанов!"
            }
        ]
    }
];
function News() {
    const [isOpen, setOpen] = (0,external_react_.useState)(false);
    const [isModal, setIsModal] = (0,external_react_.useState)({
        id: 1,
        img: _1,
        text: [
            {
                t1: "111",
                id: 1
            }
        ]
    });
    function test(img, title, text) {
        setIsModal({
            img,
            title,
            text
        });
        setOpen(true);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        title: "НОВОСТИ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mt-10 relative",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "title_main mt-10",
                            children: "НОВОСТИ"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "grid gap-4 grid-cols-4",
                            children: news.map(({ id , img , title , text  })=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    // onClick={() => setOpen(true)}
                                    onClick: ()=>test(img, title, text),
                                    className: "h-96 w-full relative overflow-hidden cursor-pointer",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: img,
                                        alt: "Новость",
                                        fill: true,
                                        sizes: "100%",
                                        className: "object-cover ease-in duration-200 hover:scale-105",
                                        priority: true
                                    })
                                }, id)).reverse()
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: ()=>setOpen(false),
                className: `absolute w-full h-full top-0 left-0 bg-black/[.9] flex items-center justify-center z-50 ${isOpen ? "block" : "hidden"} `,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col justify-center font-classic max-w-3xl p-8 bg-[#1e191a]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: isModal.img,
                            alt: "Новость",
                            width: 400,
                            height: 0,
                            className: "m-auto"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            className: "text-xl text-center mt-3",
                            children: isModal.title
                        }),
                        isModal.text.map(({ id , t1  })=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-base text-left mt-3",
                                children: t1
                            }, id))
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const pages_news = (News);


/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 5065:
/***/ ((module) => {

module.exports = require("react-icons/sl");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,61,668], () => (__webpack_exec__(7834)));
module.exports = __webpack_exports__;

})();