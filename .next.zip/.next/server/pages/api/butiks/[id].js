"use strict";
(() => {
var exports = {};
exports.id = 74;
exports.ids = [74];
exports.modules = {

/***/ 5414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _public_data_butiks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2195);

function handler(req, res) {
    const { id  } = req.query;
    const butik = _public_data_butiks__WEBPACK_IMPORTED_MODULE_0__/* .butiks.find */ .R.find((butik)=>butik.id === parseInt(id));
    res.status(200).json(butik);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [195], () => (__webpack_exec__(5414)));
module.exports = __webpack_exports__;

})();