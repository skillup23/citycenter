"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 7602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/Layout.js + 8 modules
var Layout = __webpack_require__(3668);
// EXTERNAL MODULE: ./components/SliderMain.js
var SliderMain = __webpack_require__(6561);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/site_img/nofon-shop.png
/* harmony default export */ const nofon_shop = ({"src":"/_next/static/media/nofon-shop.ef049f4a.png","height":404,"width":404,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAA1BMVEVMaXFNx9g6AAAAAXRSTlMAQObYZgAAAAlwSFlzAAAOwwAADsMBx2+oZAAAAAxJREFUeJxjYKAOAAAASAABLrg8fgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/ShopListMain.js





const shopList = [
    {
        id: 1,
        title: "Женская одежда",
        link: "/women_clothing",
        url: 'bg-[url("../public/site_img/shop-1.png")]'
    },
    {
        id: 2,
        title: "Мужская одежда",
        link: "/men_clothing",
        url: 'bg-[url("../public/site_img/shop-2.png")]'
    },
    {
        id: 3,
        title: "Детское",
        link: "/children",
        url: 'bg-[url("../public/site_img/shop-3.png")]'
    },
    {
        id: 4,
        title: "Белье",
        link: "/underwear",
        url: 'bg-[url("../public/site_img/shop-4.png")]'
    },
    {
        id: 5,
        title: "Украшение и аксессуары",
        link: "/accessories",
        url: 'bg-[url("../public/site_img/shop-5.png")]'
    },
    {
        id: 6,
        title: "Обувь и сумки",
        link: "/shoes_and_bags",
        url: 'bg-[url("../public/site_img/shop-6.png")]'
    },
    {
        id: 7,
        title: "Косметика",
        link: "/cosmetics",
        url: 'bg-[url("../public/site_img/shop-7.png")]'
    },
    {
        id: 8,
        title: "Интерьер",
        link: "/interior",
        url: 'bg-[url("../public/site_img/shop-8.png")]'
    },
    {
        id: 9,
        title: "Цветы и подарки",
        link: "/flowers_and_gifts",
        url: 'bg-[url("../public/site_img/shop-9.png")]'
    },
    {
        id: 10,
        title: "Очки",
        link: "/glasses",
        url: 'bg-[url("../public/site_img/shop-10.png")]'
    },
    {
        id: 11,
        title: "Книги",
        link: "/books",
        url: 'bg-[url("../public/site_img/shop-11.png")]'
    },
    {
        id: 12,
        title: "Парфюмерия",
        link: "/perfumery",
        url: 'bg-[url("../public/site_img/shop-12.png")]'
    }
];
function ShopListMain() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-4 w-full",
        children: shopList.map(({ id , title , link , url  })=>{
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                href: link,
                className: "block relative w-full overflow-hidden h-full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: nofon_shop,
                        alt: title,
                        width: "0",
                        height: "0",
                        style: {
                            width: "100%",
                            height: "100%"
                        },
                        priority: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `background_scale duration-300 text-center text-4xl p-6 ${url}`,
                        children: title
                    })
                ]
            }, id);
        })
    });
}
/* harmony default export */ const components_ShopListMain = (ShopListMain);

// EXTERNAL MODULE: ./components/ImageLink.js
var ImageLink = __webpack_require__(823);
;// CONCATENATED MODULE: ./public/site_img/текст-1.png
/* harmony default export */ const _1 = ({"src":"/_next/static/media/текст-1.834bcc90.png","height":104,"width":1144,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAABlBMVEX4+Pj///9njiF9AAAAAnRSTlMOEhupkf4AAAAJcEhZcwAALiMAAC4jAXilP3YAAAARSURBVHicY2BgYGBgZGRkAAAAEgAEpPx+KQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":1});
// EXTERNAL MODULE: ./public/site_img/текст-2.png
var _2 = __webpack_require__(9668);
;// CONCATENATED MODULE: ./public/site_img/event1.png
/* harmony default export */ const event1 = ({"src":"/_next/static/media/event1.9df86b84.png","height":500,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAclBMVEX59fj9/foDBAWzloSkZz+SkJDx7/Px7Ozq5ubr7OfSwqy8soKwiGupf1ZQMh/d2cTDvrvl3trHs6hxcXI8MCl7gYba2NeiiXispqWJYkuWdFmmnZainHYOBwV+UjdcNyQvFQV4ckiKdWfHk3GPhX6WUy+73niqAAAACXBIWXMAAAsTAAALEwEAmpwYAAAARUlEQVR4nAXBhQHAMAwDMHeFpDxmhv9fnAQi6+bVZxCEV8eVAdOF/YsWaIrlVcpBF+0QUnpQ6lpO2xkBwdyP8gYMVwTLP32VA2O0963aAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/event2.png
/* harmony default export */ const event2 = ({"src":"/_next/static/media/event2.37f85fce.png","height":598,"width":598,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAflBMVEVnhYHJpH7KjJXZpGTKx8S0k4fXvqqotbbBtqG5v7lfaGmzlERoY03k5+jY2NfSxaDm3+LBubnCqZLn49rAnYnRsJ/c0LW7rKSSkp7GmGmujndfWFTCuaTcvIStiFm4vsi1j3GhXmS+foq3nYNebXrhYWiINVW9VnGSe3iKaUmHO+1oAAAADXRSTlP8/vj4/vf5/v7++Pj5t8FhmwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAEhJREFUeJwFwQUCgCAQBMC18wCRtlv//0FnUDFGRIJQcj72JBg6aVRvzYxUd245eICarAvfUCDy63b5t4DU+3MPJ5DlcdK0qH+qzQTVkE9f8AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/event3.png
/* harmony default export */ const event3 = ({"src":"/_next/static/media/event3.c5869d2c.png","height":1000,"width":1000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAY1BMVEVgY3F/kZV9g4ySkYGEfnJ2jJtnbnV+emh/joFLYW+cm5Vpc32rrKyNfHCSnKSntLG3ys+BfYWMi42ptLh2dGPR0tCohG2ZloKpqJi/xcC71+N2eYVSVWU+T0ibqbN7eYNGWmWonrMpAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAQ0lEQVR4nAXBhwGAIBAAsZP2oNLsXfef0oRtNSIyafZslqilpRw1Gu97Su5wvhlxN5AaS/hO6ELA2nqhUDzJvf3cDj9m5wLYS/TymwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/event4.png
/* harmony default export */ const event4 = ({"src":"/_next/static/media/event4.76908c1a.png","height":500,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAaVBMVEVQXGqLmqCqwMdcY2uDcmybiXxeXlw6PEZreYOTp66VmJp6dnpjS0MnIyyynIg3S1PJv7Df39e6wsCHo7CBlZxncnGztK1JUVxwYFiZbVSLh4fr7OTLyMDHysSJZlQjEQpQKRlMWFdRRDqdegXbAAAACXBIWXMAAAsTAAALEwEAmpwYAAAARElEQVR4nAXBhQHAMAwDMJeSMoyZ/j9yEroJnIgKpJiX+N2MHkWv1/PCAqSjkQBY+SQcrA86sBvQas5mcxZ7O85q1PgDbigDG70GzA0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/PrezentMain.jpg
/* harmony default export */ const PrezentMain = ({"src":"/_next/static/media/PrezentMain.2ec4a4d2.jpg","height":117,"width":1420,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAABAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAVEAEBAAAAAAAAAAAAAAAAAAAA0f/EABUBAQEAAAAAAAAAAAAAAAAAAAAB/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8AkaAK/9k=","blurWidth":8,"blurHeight":1});
// EXTERNAL MODULE: ./public/site_img/лого-монитор.png
var _ = __webpack_require__(384);
// EXTERNAL MODULE: ./public/site_img/лого-монитор-2.png
var site_img_2 = __webpack_require__(9731);
;// CONCATENATED MODULE: ./public/site_img/кино-иконка-1.png
/* harmony default export */ const site_img_1 = ({"src":"/_next/static/media/кино-иконка-1.d27d0854.png","height":478,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAHlBMVEX9/f38/Pz+/v5MaXH+/v7///////////////////+DSKM2AAAACnRSTlNPEFwAK2t6Gj0BOQ1NYgAAAAlwSFlzAAAuIwAALiMBeKU/dgAAADRJREFUeJwdxMcRwDAQA7EleUHqv2GNjQdIzbhPiFtZhxoSdYFLWuC0wX1AK634+etGns19HWEAw7lN8ssAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/кино-иконка-2.png
/* harmony default export */ const public_site_img_2 = ({"src":"/_next/static/media/кино-иконка-2.93daff41.png","height":454,"width":502,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAFVBMVEX+/v7+/v76+vr////+/v7+/v7+/v56eN9uAAAAB3RSTlNBMwRNWCSKNyIzJgAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAC1JREFUeJwVxsERwEAQwjB7geu/5Ez0EkOVwe7uBuUPhUQTsLtbxAZayQN8+QAObgB6HeKeawAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/site_img/кино-иконка-3.png
/* harmony default export */ const _3 = ({"src":"/_next/static/media/кино-иконка-3.b9ef2549.png","height":414,"width":501,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAIVBMVEX////+/v5MaXH+/v7////9/f3+/v7+/v7+/v7///////+pxTGSAAAAC3RSTlM5YABuEExYh68hfy8RWt0AAAAJcEhZcwAALiMAAC4jAXilP3YAAAAxSURBVHicJcbJDQAgEAOxSfYC+i8YCfwyR+qWBpzsbcCxFi818+PMNKhCoRLOiNP2BRaCALDEV4HHAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/site_img/кино-иконка-4.png
/* harmony default export */ const _4 = ({"src":"/_next/static/media/кино-иконка-4.88744af5.png","height":500,"width":472,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAKlBMVEVMaXH////+/v7////+/v7+/v79/f39/f39/f35+fnv7+/8/Pz////4+PhRZJZGAAAADnRSTlMATVxpdYwaO6gOCH2SJtcn0hUAAAAJcEhZcwAALiMAAC4jAXilP3YAAAA4SURBVHicHcZJEoAwDASxHi/YTuD/36USnURn7ATIiooHML3SiY+N3bDQmcMyj8L5JCbIMu/s/gEh6wD5JfHq7gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/site_img/1-дон-базилио.png
/* harmony default export */ const _1_ = ({"src":"/_next/static/media/1-дон-базилио.2497568c.png","height":256,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAElBMVEX8/Pz8/Pz////9/f3///////8Bq1uoAAAABnRSTlM2LQkhRRqxPynzAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAIUlEQVR4nAXBAQEAAAzCoOl8/8oH6pGzSKERlySTHhvXBwUEAEneZ56LAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/site_img/3-френч-кис.png
/* harmony default export */ const _3_ = ({"src":"/_next/static/media/3-френч-кис.11fd35ce.png","height":218,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAD1BMVEX+/v7////////+/v7s7OzdpDAbAAAABXRSTlMVQCVTBrcMadcAAAAJcEhZcwAALiMAAC4jAXilP3YAAAAcSURBVHicHcGBDQAACMKwMfn/ZqMtqqBkJofyugH7ACH00RgAAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/site_img/игратория.png
/* harmony default export */ const site_img_ = ({"src":"/_next/static/media/игратория.9cc6012c.png","height":207,"width":501,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAFVBMVEXS0tXi4uLU1NPW1tXp6enU1NTT09Oyj/8LAAAAB3RSTlMLI8u5F6F2P/f9tAAAAAlwSFlzAAAOwwAADsMBx2+oZAAAABpJREFUeJxjYIABVmZmJiZmJjYGRhBgYWQBAAGpAClS0CwYAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/site_img/LapinHouse.png
/* harmony default export */ const LapinHouse = ({"src":"/_next/static/media/LapinHouse.ebeb18da.png","height":47,"width":315,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAAD1BMVEXPz8+bm5qjo6Ozs7O+vr7SyIHhAAAACXBIWXMAABJ0AAASdAHeZh94AAAAEUlEQVR4nGNgYGJkYWZiZAAAAEUADnZjCCAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./public/site_img/3-метро-беби.png
/* harmony default export */ const site_img_3_ = ({"src":"/_next/static/media/3-метро-беби.9feaf24e.png","height":238,"width":902,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAGFBMVEX////9/f3+/v7////////8/Pz8/Pz////gYtvQAAAACHRSTlNuJTZHLF1eE/n1CpsAAAAJcEhZcwAALiMAAC4jAXilP3YAAAAaSURBVHicY2BgY2VgYGZiYWBmYmRkYWdkAgABeQAq282gMwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/site_img/2-книжный-лабиринт.png
/* harmony default export */ const _2_ = ({"src":"/_next/static/media/2-книжный-лабиринт.46b73961.png","height":120,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAGFBMVEXT09PPz8/y8vJoaGiUlJTg4N+Wlpbo6Oj4UZDpAAAACHRSTlP8/Pz8/Pz8/C8FVBoAAAAJcEhZcwAALiMAAC4jAXilP3YAAAAaSURBVHicY2BmYWJgZGBkYmBmYWdkYGBkBQABOQAjpU2SuQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
// EXTERNAL MODULE: external "react-icons/hi"
var hi_ = __webpack_require__(1111);
// EXTERNAL MODULE: external "react-icons/md"
var md_ = __webpack_require__(4041);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./public/data/data.js
var data = __webpack_require__(5743);
// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__(9816);
var style_default = /*#__PURE__*/__webpack_require__.n(style_);
;// CONCATENATED MODULE: external "@pbe/react-yandex-maps"
const react_yandex_maps_namespaceObject = require("@pbe/react-yandex-maps");
;// CONCATENATED MODULE: ./components/YandexMap.js



const YandexMap = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "jsx-3d29dd9b6dc48ebe" + " " + "map",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_yandex_maps_namespaceObject.YMaps, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_yandex_maps_namespaceObject.Map, {
                    defaultState: {
                        center: [
                            45.001269,
                            38.961937
                        ],
                        zoom: 17,
                        controls: [
                            "zoomControl",
                            "fullscreenControl"
                        ]
                    },
                    className: "yaMapMain",
                    modules: [
                        "control.ZoomControl",
                        "control.FullscreenControl"
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_yandex_maps_namespaceObject.Placemark, {
                        defaultGeometry: [
                            45.0015,
                            38.96194
                        ],
                        properties: {
                            iconCaption: "ул. Индустриальная, 2"
                        }
                    })
                })
            }),
            jsx_runtime_.jsx((style_default()), {
                id: "3d29dd9b6dc48ebe",
                children: ".map.jsx-3d29dd9b6dc48ebe{margin-top:0px}"
            })
        ]
    });
/* harmony default export */ const components_YandexMap = (YandexMap);

;// CONCATENATED MODULE: ./pages/index.js
































function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        title: "ГЛАВНАЯ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(SliderMain/* default */.Z, {
                data: data/* sliderTop */.un,
                dots: false
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "border_section border-b-0",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto pr-5",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "title_main text-right mt-12",
                            children: "СЦЕНАРИИ"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: _1,
                            alt: "slide1",
                            width: "0",
                            height: "0",
                            sizes: "100vw",
                            className: "w-3/5 h-auto block ml-auto mt-2",
                            priority: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "w-2/5 text-right ml-auto subtitle_main mt-8",
                            children: "ТРК “СИТИ ЦЕНТР” — место притяжения успешных людей. В комплексе представлено большое количество премиальных брендов с разнообразным ассортиментом, рестораны итальянской кухни и VIP-кинотеатр. В ТРК \xabСИТИ ЦЕНТР\xbb вы с удовольствием проведёте время в комфортной обстановке спокойствия и люксового шоппинга."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row mt-10",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/",
                                    className: "flex flex-col items-center -mt-96 z-10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: event1,
                                            alt: "событие 1",
                                            width: 450,
                                            className: "ease-in duration-300 grayscale hover:grayscale-0",
                                            priority: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-white max-w-xs -mt-12 z-20",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-center text-2xl text-black py-4 px-4",
                                                children: [
                                                    "Проведите романтическое ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    "свидание"
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/",
                                    className: "flex flex-col items-center -mx-28 -mt-36",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: event2,
                                            alt: "событие 2",
                                            width: 700,
                                            className: "ease-in duration-300 grayscale hover:grayscale-0",
                                            priority: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-white max-w-xs -mt-12 z-20",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-center text-2xl text-black py-4 px-5",
                                                children: [
                                                    "Семейный праздник и ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    "детский день рождения"
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/",
                                    className: "flex flex-col items-center -mt-10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: event3,
                                            alt: "событие 3",
                                            width: 500,
                                            className: "ease-in duration-300 grayscale hover:grayscale-0",
                                            priority: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-white max-w-xs -mt-12 z-20",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-center text-2xl text-black py-4 px-5",
                                                children: [
                                                    "Приготовьтесь ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    "к особому случаю"
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/",
                                    className: "flex flex-col items-center -ml-10 mt-10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: event4,
                                            alt: "событие 4",
                                            width: 500,
                                            className: "ease-in duration-300 grayscale hover:grayscale-0",
                                            priority: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-white max-w-xs -mt-12 z-20",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-center text-2xl text-black py-4 px-5",
                                                children: [
                                                    "Проведите ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    "деловую встречу"
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mb-28",
                id: "bitiki",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "title_main mt-12",
                            children: "БУТИКИ"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(components_ShopListMain, {})
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "relative",
                id: "kinoteatr",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(SliderMain/* default */.Z, {
                        data: data/* sliderCenter */.KI,
                        dots: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: _2/* default */.Z,
                        alt: "slide1",
                        width: "0",
                        height: "0",
                        sizes: "100%",
                        className: "absolute top-6 right-0 w-1/12"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mt-20",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto pr-5 flex flex-row gap-12",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col w-1/2 pl-3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex gap-12 w-1/2 mb-12 items-start",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: _/* default */.Z,
                                            alt: "Лого Монитор",
                                            width: "200",
                                            height: "0",
                                            sizes: "100%",
                                            className: ""
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: site_img_2/* default */.Z,
                                            alt: "Лого Монитор Делюкс",
                                            width: "150",
                                            height: "0",
                                            sizes: "100%",
                                            className: ""
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "mb-8 text-xl",
                                    children: "\xabМОНИТОР Сити de Luxe\xbb — кинотеатр нового уровня, соответствующий актуальным трендам мирового кинопоказа и современного дизайна. Кинотеатр оборудован высококачественной кинопроекционной системой Sony Digital.Cinema 4K с функцией показа максимально чёткого изображения."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "mb-8 text-xl",
                                    children: "В двух комфортных залах на 62 и 64 места установлены удобные кресла с выдвижными столиками, огромным личным пространством и большим расстоянием между рядами. Все кресла имеют выдвижную слайдер-систему. Последний ряд оборудован раскладывающимися креслами-реклайнерами с подставкой для ног, которые можно привести в полностью горизонтальное положение."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "mb-8 text-xl",
                                    children: "Также у нас вы можете заказать еду из ресторана прямо в кинозал. Официант принесёт заказ и разместит его на столике у кресла."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row flex-wrap w-1/2 items-start content-start",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row w-1/2 items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: site_img_1,
                                            alt: "Кесло",
                                            width: "100",
                                            height: "0",
                                            sizes: "100%",
                                            className: "pr-8"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "w-3/5 text-4xl",
                                            children: "Только Vip‑кресла"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row w-1/2 items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: public_site_img_2,
                                            alt: "Кесло",
                                            width: "100",
                                            height: "0",
                                            sizes: "100%",
                                            className: "pr-8"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "w-3/5 text-4xl",
                                            children: "Lounge-зона"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row w-1/2 items-center mt-28",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: _3,
                                            alt: "Кесло",
                                            width: "100",
                                            height: "0",
                                            sizes: "100%",
                                            className: "pr-8"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "w-3/5 text-4xl",
                                            children: "Sony digital cinema 4k"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row w-1/2 items-center mt-28",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: _4,
                                            alt: "Кесло",
                                            width: "100",
                                            height: "0",
                                            sizes: "100%",
                                            className: "pr-8"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "w-3/5 text-4xl",
                                            children: "Обслуживание официантами"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mt-20",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container mx-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "flex w-full items-center justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://kinomonitor.ru/cinemas/sity/schedule/#tabs",
                                target: "_blank",
                                className: "link_kino",
                                children: "Расписание"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/events",
                                className: "link_kino",
                                children: "События"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://kinomonitor.ru/cinemas/sity/hallplans/",
                                target: "_blank",
                                className: "link_kino",
                                children: "Схема зала"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://kinomonitor.ru/cinemas/sity/#tabs",
                                target: "_blank",
                                className: "link_kino",
                                children: "Контакты"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mb-28",
                id: "restoran",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "title_main mt-20",
                            children: "РЕСТОРАНЫ"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-center items-start gap-48 my-24",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                                    href: "http://donbazilio.ru/",
                                    src: _1_,
                                    alt: "Дон Базилио"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                                    href: "https://frenchkiss.ru/stores/",
                                    src: _3_,
                                    alt: "French kiss"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mb-28",
                id: "detyam",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "title_main mt-20",
                            children: "ДЕТЯМ"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-center items-center my-24 gap-36",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                                    href: "https://www.igratoria.com/tarify",
                                    src: site_img_,
                                    alt: "Игратория"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                                    href: "/children/29",
                                    src: LapinHouse,
                                    alt: "Lapin House"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/children/69",
                                    className: "w-1/3 h-fill text-5xl ease-in duration-200 hover:scale-105",
                                    children: "Дом детской моды"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: PrezentMain,
                            alt: "ПОДАРКИ И ТОВАРЫ ДЛЯ ДЕТЕЙ",
                            width: "fill",
                            height: "0",
                            sizes: "100%",
                            className: "",
                            priority: true
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-center items-center my-24 gap-36",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                                    href: "/children/30",
                                    src: site_img_3_,
                                    alt: "Metro Baby"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ImageLink/* default */.Z, {
                                    href: "/children/31",
                                    src: _2_,
                                    alt: "Книжный лабиринт"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-1/3"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mt-20",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "title_main mt-20",
                            children: "КОНТАКТЫ"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "pr-5 flex flex-row gap-12",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col w-1/3 pl-3 justify-between",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-row w-fill items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(hi_.HiLocationMarker, {
                                                    className: "text-xl mr-5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-xl",
                                                    children: "Г. КРАСНОДАР, УЛ. ИНДУСТРИАЛЬНАЯ, 2"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-row w-fill items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaPhoneAlt, {
                                                    className: "text-xl mr-5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "tel:88612134700",
                                                    className: "text-xl",
                                                    children: "8 (861) 213 47 00"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-row w-fill items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(md_.MdEmail, {
                                                    className: "text-xl mr-5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "mailto:info@citycenter.ru",
                                                    className: "text-xl",
                                                    children: "INFO@CITYCENTER.RU"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-row w-fill items-start",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiTimeFill, {
                                                    className: "text-xl mr-5 mt-1"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl",
                                                            children: "ЧАСЫ РАБОТЫ:"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl mt-2",
                                                            children: "УНИВЕРСАМ \xabПЕРЕКРЕСТОК\xbb - КРУГЛОСУТОЧНО"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl mt-2",
                                                            children: "КИНОТЕАТР \xabCITI DE LUXE\xbb - ДО ОКОНЧАНИЯ ПОСЛЕДНЕГО СЕАНСА"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl mt-2",
                                                            children: "КАФЕ И РЕСТОРАН - ДО 23:00"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl mt-2",
                                                            children: "МАГАЗИНЫ - С 10:00 ДО 22:00"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-row w-fill items-start",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaBus, {
                                                    className: "text-xl mr-5 mt-1"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl",
                                                            children: "КАК ДОБРАТЬСЯ:"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl mt-2",
                                                            children: "МАРШРУТНОЕ ТАКСИ № 3, 5А, 7А, 8А, 21, 26А, 44, 95"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl mt-2",
                                                            children: "ТРОЛЛЕЙБУСОМ № 9, 10, 15"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "text-xl mt-2",
                                                            children: "ТРАМВАЕМ № 4, 2"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex flex-row flex-wrap w-2/3 items-start content-start",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_YandexMap, {})
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 5065:
/***/ ((module) => {

module.exports = require("react-icons/sl");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,61,668,45], () => (__webpack_exec__(7602)));
module.exports = __webpack_exports__;

})();