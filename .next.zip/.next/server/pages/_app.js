(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6005:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__bebas_4b1c3e', '__bebas_Fallback_4b1c3e'"},
	"className": "__className_4b1c3e",
	"variable": "__variable_4b1c3e"
};


/***/ }),

/***/ 762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/@next/font/local/target.css?{"path":"pages\\_app.js","import":"","arguments":[{"src":"../public/fonts/BebasNeueRegular.woff2","variable":"--font-bebas","weight":"normal"}],"variableName":"bebas"}
var BebasNeueRegular_woff2_variable_font_bebas_weight_normal_variableName_bebas_ = __webpack_require__(6005);
var BebasNeueRegular_woff2_variable_font_bebas_weight_normal_variableName_bebas_default = /*#__PURE__*/__webpack_require__.n(BebasNeueRegular_woff2_variable_font_bebas_weight_normal_variableName_bebas_);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/NavigationLoader.js



const LOADER_THRESHOLD = 250;
function NavigationLoader() {
    //   const { text = 'Loading...' } = props;
    const [isLoading, setLoading] = external_react_default().useState(false);
    const router = (0,router_.useRouter)();
    external_react_default().useEffect(()=>{
        let timer;
        const start = ()=>timer = setTimeout(()=>setLoading(true), LOADER_THRESHOLD);
        const end = ()=>{
            if (timer) {
                clearTimeout(timer);
            }
            setLoading(false);
        };
        router.events.on("routeChangeStart", start);
        router.events.on("routeChangeComplete", end);
        router.events.on("routeChangeError", end);
        return ()=>{
            router.events.off("routeChangeStart", start);
            router.events.off("routeChangeComplete", end);
            router.events.off("routeChangeError", end);
            if (timer) {
                clearTimeout(timer.current);
            }
        };
    }, [
        router.events
    ]);
    if (!isLoading) return null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "navigation-loader",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "preloader-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                ]
            }),
            ";"
        ]
    });
}

;// CONCATENATED MODULE: ./pages/_app.js




// const bebas = localFont({
//   src: [
//     {
//       path: '../public/fonts/BebasNeueRegular.woff2',
//       weight: 'normal',
//       variable: '--font-bebas',
//     },
//     {
//       path: '../public/fonts/BebasNeueLight.woff2',
//       weight: '300',
//       variable: '--font-light',
//     },
//     {
//       path: '../public/fonts/BebasNeueBold.woff2',
//       weight: 'bold',
//       variable: '--font-bold',
//     },
//   ],
// });
function App({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(BebasNeueRegular_woff2_variable_font_bebas_weight_normal_variableName_bebas_default()).variable} font-sans`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(NavigationLoader, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    });
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(762));
module.exports = __webpack_exports__;

})();