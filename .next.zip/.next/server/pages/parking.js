"use strict";
(() => {
var exports = {};
exports.id = 896;
exports.ids = [896];
exports.modules = {

/***/ 7554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3668);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




function Parking() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        title: "Парковка",
        children: [
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "3162d9804c822d47",
                children: "ul.jsx-3162d9804c822d47 li.jsx-3162d9804c822d47{list-style-type:disc;margin-left:30px}p.jsx-3162d9804c822d47,ol.jsx-3162d9804c822d47{margin-top:10px}"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "jsx-3162d9804c822d47" + " " + "mt-10",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "jsx-3162d9804c822d47" + " " + "container mx-auto",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "jsx-3162d9804c822d47" + " " + "text-4xl mt-20 text-center w-2/5 m-auto",
                            children: "ПРАВИЛА ПОЛЬЗОВАНИЯ ПЛАТНОЙ НЕОХРАНЯЕМОЙ ПАРКОВКОЙ НА ТЕРРИТОРИИ ТОРГОВО-РАЗВЛЕКАТЕЛЬНОГО КОМПЛЕКСА \xabСИТИ ЦЕНТР\xbb*"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "jsx-3162d9804c822d47" + " " + "font-classic w-4/5 m-auto mt-10 text-justify",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "1.\xa0",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Термины и определения:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Организатор парковки"
                                                }),
                                                " – Общество с ограниченной ответственностью Группы Компаний \xabСИТИ ЦЕНТР\xbb, ОГРН: 1022301436145, ИНН: 2309076513, юридический адрес: г. Краснодар, ул. Индустриальная, дом 2, офис 13, телефон: (861)\xa0213\xa047\xa000, сайт: http://citycenter.ru/."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Платная парковка"
                                                }),
                                                " – специально отведенная платная неохраняемая автоматизированная площадка, предназначенная для временного размещения транспортных средств, обозначенная дорожными знаками \xabМесто стоянки\xbb, \xabПлатные услуги\xbb и разметкой, расположенная по адресу: г. Краснодар, ул. Индустриальная, 2, на которой Организатором парковки оказываются платные услуги парковки."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "ТРК"
                                                }),
                                                " – Торгово-развлекательный комплекс \xabСИТИ ЦЕНТР\xbb, расположенный по адресу: г. Краснодар, ул. Индустриальная, 2."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Услуга "
                                                }),
                                                "– предоставление права временного пользования Платной парковкой для целей размещения транспортного средства на специально предназначенном для этого месте."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Парковочное место"
                                                }),
                                                " – специально обозначенное место на Платной парковке, предназначенное для размещения одного транспортного средства."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Пользователь Платной парковки"
                                                }),
                                                " – любое лицо, воспользовавшееся услугами Платной парковки, предоставляемыми Организатором парковки."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Парковочный талон"
                                                }),
                                                " – печатный документ или временная пластиковая карта, выданные Пользователю Организатором парковки, фиксирующие дату и время начала фактического предоставления Услуги, с помощью которых осуществляется въезд на Платную парковку и выезд с Платной парковки, а также предназначенные для расчета и уплаты Пользователем Платной парковки стоимости Услуги."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Система"
                                                }),
                                                " – комплекс программно-аппаратных средств, позволяющих в автоматическом режиме производить считывание Парковочных талонов, прием денежных средств в оплату Услуг, выдачу Парковочных талонов и иные технически возможные операции специальным оборудованием."
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "Заезжая на территорию Платной парковки Пользователь Платной парковки соглашается принимать данные Системы в качестве достоверной информации о соответствующих фактах, в том числе об оплате и фактическом предоставлении Услуги."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "Получение Пользователем Платной парковки Парковочного талона признается аналогом собственноручной подписи Пользователя Платной парковки под содержащимися в Системе в электронной форме документами, подтверждающими факты пользования Платной парковкой со стороны Пользователя Платной парковки и получения им Услуги."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Паркомат"
                                                }),
                                                " – автономное терминальное устройство, обеспечивающее интерактивное взаимодействие с Пользователем Платной парковки для предоставления ему возможности внесения оплаты за Услугу, иных платежей, а также других операций, предусмотренных его техническими возможностями."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Инвалид"
                                                }),
                                                " – лицо, которое имеет нарушение здоровья со стойким расстройством функций организма, обусловленное заболеваниями, последствиями травм или дефектами, приводящее к ограничению жизнедеятельности и вызывающее необходимость его социальной защиты."
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "Ограничение жизнедеятельности – полная или частичная утрата лицом способности или возможности осуществлять самообслуживание, самостоятельно передвигаться, ориентироваться, общаться, контролировать свое поведение, обучаться и заниматься трудовой деятельностью."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "В зависимости от степени расстройства функций организма лицам, признанным инвалидами, устанавливается группа инвалидности, а лицам в возрасте до 18 лет устанавливается категория \xabребенок-инвалид\xbb. Признание лица инвалидом осуществляется федеральным учреждением медико-социальной экспертизы. Порядок и условия признания лица инвалидом устанавливаются Правительством Российской Федерации."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "jsx-3162d9804c822d47",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "jsx-3162d9804c822d47",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                className: "jsx-3162d9804c822d47",
                                                children: "Транспортные средства инвалидов"
                                            }),
                                            " – легковые автомобили, управляемые Инвалидами, или используемые для их перевозки, на которых установлен опознавательный знак \xabИнвалид\xbb и информация о которых внесена в федеральный реестр инвалидов."
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "2.\xa0\xa0",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Режим работы Платной парковки – круглосуточный, 7 (Семь) дней в неделю."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "3. Организатор парковки не оказывает услуг по хранению и (или) охране транспортных средств, и не несет ответственности за сохранность транспортного средства Пользователя Платной парковки и находящегося в нем имущества, а также за вред, причиненный транспортному средству третьими лицами."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "4. На территорию Платной парковки запрещен доступ: — Транспортных средств, максимальная разрешенная масса которых превышает 3 500 кг и/или число сидячих мест, в которых, помимо места водителя, превышает восемь мест и/или занимающих более 1 (Одного) парковочного места; — Мототранспортных средств (мопедов, мотороллеров, скутеров и т.п.), за исключение мотоциклов; — Составов транспортных средств, а также транспортных средств с прицепом; — Транспортных средств, в отношении которых Организатором парковки принято решение о не допуске, в том числе в связи с нарушениями Правил пользования Платной парковкой."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "5. Въезд на территорию Платной парковки возможен только при наличии свободных Парковочных мест."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "6. Организатором парковки может по техническим причинам приостановить и/или ограничить въезд на территорию Платной парковки."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "7. Движение, остановка, стоянка на территории Платной парковки осуществляются в соответствии с требованиями Правил дорожного движения Российской Федерации, в том числе в части дорожных знаков и разметки, включая разметку Парковочных мест."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "8. Парковочные места, выделенные на территории Платной парковки в соответствии с действующим законодательством Российской Федерации для размещения Транспортных средств инвалидов, не должны заниматься другими транспортными средствами."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "9.\xa0",
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                "Для въезда на территорию Платной парковки необходимо",
                                                " "
                                            ]
                                        }),
                                        "нажать кнопку на въездном терминале и получить Парковочный талон. После полного открытия шлагбаума въехать на территорию Платной парковки и поставить транспортное средство на одном из свободных Парковочных мест, строго соблюдая нанесенную разметку."
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47" + " " + "py-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
                                                className: "jsx-3162d9804c822d47",
                                                children: "Вниманию Пользователей Платной парковки:"
                                            })
                                        }),
                                        " ",
                                        "В случае возникновения каких-либо затруднений с проездом на территорию Платной парковки (не выдается Парковочный талон, не поднимается шлагбаум) просим связаться со службой поддержки Организатора парковки, нажав на кнопку переговорного устройства, которая находится на лицевой панели стойки выдачи Парковочных талонов либо позвонив по телефону: (861) 213 47 07."
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "10. Пользователь Платной парковки обязан исполнять требования сотрудников службы охраны о соблюдении разметки и Правил пользования Платной парковкой."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "11. Организатор парковки вправе эвакуировать (перемещать, удалять) с Платной парковки за счет Пользователь Платной парковки транспортные средства, размещенные с нарушением Правил дорожного движения Российской Федерации, дорожной разметки и настоящих Правил, для обеспечения безопасности дорожного движения, устранения препятствий движению транспортных средств и (или) пешеходов и иного соблюдения настоящих Правил. В указанных случаях риски случайного повреждения или гибели транспортного средства и иного имущества несет Пользователь Платной парковки, допустивший нарушение."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "12. Получение Пользователем Платной парковки Парковочного талона считается заключение Пользователем Платной парковки с Организатором парковки договора предоставления Услуги платной парковки на условиях, изложенных в настоящих Правилах."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "13.\xa0",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Стоимость услуг (тарифы Платной парковки"
                                        }),
                                        "):"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("table", {
                                    className: "jsx-3162d9804c822d47" + " " + "my-10",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                        className: "jsx-3162d9804c822d47",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "jsx-3162d9804c822d47",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            className: "jsx-3162d9804c822d47" + " " + "mr-5",
                                                            children: "Наименование"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            className: "jsx-3162d9804c822d47" + " " + "p-3",
                                                            children: "Условия и стоимость"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "jsx-3162d9804c822d47" + " " + "border-t",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            className: "jsx-3162d9804c822d47",
                                                            children: "\xabТранзит\xbb:"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47" + " " + "p-3",
                                                        children: "Для транспортных средств, простоявших 15 (Пятнадцать) минут и менее, с 1 (Первой) по 15 (Пятнадцатую) минуту включительно – 200,00 (Двести) рублей."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "jsx-3162d9804c822d47" + " " + "border-t",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            className: "jsx-3162d9804c822d47",
                                                            children: "\xabБазовый\xbb:"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47" + " " + "p-3",
                                                        children: "Для транспортных средств, простоявших более 15 (Пятнадцати) минут, первые 2 (Два) часа – бесплатно. Начиная с 3 (Третьего) часа и каждый последующий час – 200,00 (Двести) рублей за 1 (Один) час. Тарификация – почасовая, начисляется с первой минуты каждого часа.*"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "jsx-3162d9804c822d47" + " " + "border-t",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            className: "jsx-3162d9804c822d47",
                                                            children: "\xabКарусель\xbb:"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47" + " " + "p-3",
                                                        children: "Для транспортных средств, простоявших 119 (Сто девятнадцать) минут и менее, повторный въезд на парковку в течение 30 (Тридцати) минут после выезда оплачивается с 1 (Первой) минуты по тарифу – 200,00 (Двести) рублей за 1 (Один) час. Тарификация – почасовая, начисляется с первой минуты каждого повторного въезда.*"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "jsx-3162d9804c822d47" + " " + "border-y",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            className: "jsx-3162d9804c822d47",
                                                            children: "\xabСуточный\xbb:"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "jsx-3162d9804c822d47" + " " + "p-3",
                                                        children: "Для транспортных средств, простоявших более 6 (Шести) часов подряд, до истечения 24 (Двадцати четырех) часов с момента заезда – 1\xa0200 (Одна тысяча двести) рублей, после истечения 24 (Двадцати четырех) часов с момента заезда – каждый последующий час – 200,00 (Двести) рублей за 1 (Один) час. Тарификация – почасовая, начисляется с первой минуты каждого часа.*"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        className: "jsx-3162d9804c822d47",
                                        children: "* Неполный час оплачивается как целый"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        className: "jsx-3162d9804c822d47",
                                        children: "Все цены указаны с учетом НДС. "
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "14. Инвалиды пользуются местами для парковки Транспортных средств инвалидов бесплатно, в том числе, если на Платной парковке отсутствуют свободные места, специально предназначенные для размещения Транспортных средств инвалидов. Для выезда Инвалида с территории Платной парковки в специальном льготном порядке необходимо обратиться на информационную стойку, расположенную на 1 (Первом) этаже центрального атриума ТРК, либо позвонить по телефону технической поддержки: (861) 213 47 07."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "15. Право бесплатного въезда на территорию Платной парковки предоставляется для транспортных средств, используемых для осуществления деятельности пожарной охраны, полиции, медицинской скорой помощи, аварийно-спасательных служб, военной автомобильной инспекции, а также транспортных средств федерального органа исполнительной власти в области обеспечения безопасности, федерального органа исполнительной власти в области государственной охраны, военной полиции Вооруженных Сил Российской Федерации, войск национальной гвардии Российской Федерации, следственных органов Следственного комитета Российской Федерации, федерального органа исполнительной власти, осуществляющего специальные функции в сфере обеспечения федеральной фельдъегерской связи в Российской Федерации, используемых в связи со служебной необходимостью."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "16. Пользователям Платной парковки и иным посетителям Платной парковки запрещается:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Парковать транспортные средства на местах, выделенных для размещения Транспортных средств инвалидов, в отсутствие соответствующего права, на проезжих частях, въездах и выездах Платной парковки, на поворотах, а так же в любых других местах, кроме специально отведенных Парковочных мест, обозначенных соответствующей разметкой."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Нарушать требования дорожных знаков, разметки, Правил дорожного движения Российской Федерации, настоящих Правил."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Допускать остановку, стоянку транспортных средств в нарушение дорожных знаков и разметки, в том числе под видом аварийных (с включением знака аварийной остановки), иным образом создавать или провоцировать создание любых пробок (заторов), снижение пропускной способности территории, предназначенной для движения транспортных средств."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Допускать опасное вождение, незаконное превышение ограничения скорости движения транспортных средств, умышленно резкие ускорения, торможения, изменения направления их движения, повышенный шум от них (агрессивное вождение)."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Проводить на Платной парковке любого рода маркетинговые, стимулирующие, рекламные мероприятия, распространять рекламную и иную информацию, осуществлять торговую или иную коммерческую деятельность."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Размещать на Платной парковке транспортные средства без государственных регистрационных знаков, в аварийном состоянии, со значительными кузовными повреждениями, на буксире, при наличии утечки ГСМ."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Проносить (провозить) на Платную парковку взрывчатые, горючие, токсичные вещества, взрывные устройства, пиротехнические изделия, пользоваться на Платной парковке открытым огнем."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Допускать повреждение, разрушение дорожного покрытия, дорожных знаков, разметки, парковочного оборудования и иного имущества на Платной парковке."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "При пользовании тележками магазинов – оставлять тележки на проезжих частях или загораживать ими Парковочные места, перемещать тележки за пределы Платной парковки, допускать их неконтролируемое перемещение, причинение ими вреда транспортным средствам."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "17.\xa0",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Оплата Платной парковки:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Оплата Услуги Платной парковки возможна в наличной или безналичной форме. Оплата наличными возможна только с использованием Паркомата, расположенного возле главного входа в ТРК. Оплата на выезде с использованием выездного терминала шлагбаумов возможна только в безналичной форме."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Оплата возможна денежными купюрами номиналом 50, 100, 200, 500, 1 000, 2\xa0000 рублей, при необходимости Пользователю Платной парковки выдается остаток денежных средств (сдача). Размен денег не предусмотрен."
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Для оплаты Услуги Платной парковки с использованием Паркомата"
                                                }),
                                                " ",
                                                "необходимо отсканировать Парковочный талон в специальном отверстии, после чего на сенсорном экране Паркомата автоматически отобразится сумма для оплаты на основании действующего тарифа. После оплаты Пользователю Платной парковки выдается чек и в случае расчета наличными денежными средствами сдача (при необходимости)."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "Для оплаты Услуги Платной парковки "
                                                }),
                                                "с использованием выездного терминала шлагбаумов необходимо отсканировать Парковочный талон, после чего на сенсорном экране терминала автоматически отобразится сумма для оплаты на основании действующего тарифа. Оплата с использованием выездного терминала шлагбаумов возможна только в безналичном порядке."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
                                                        className: "jsx-3162d9804c822d47",
                                                        children: "Вниманию Пользователей Платной парковки:"
                                                    })
                                                }),
                                                " ",
                                                "В случае возникновения каких-либо проблем с проведением оплаты просим связаться со службой поддержки Организатора парковки, нажав на кнопку переговорного устройства либо позвонив по телефону: (861) 213 47 07."
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "18. Для выезда транспортного средства с территории Платной парковки без оплаты Пользователю Платной парковки предоставляется",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "15 (Пятнадцать) минут"
                                        }),
                                        " с момента окончания оплаченного периода времени."
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "19.\xa0",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Для выезда Пользователю Платной парковки необходимо"
                                        }),
                                        " ",
                                        "убедиться, что не превышен лимит времени бесплатного пользования Услугой Платной парковки. Если лимит бесплатного времени превышен, необходимо в полном объеме оплатить стоимость полученной Услуги в соответствии с действующими тарифами Организатора парковки."
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "После необходимо подъехать выездному терминалу и отсканировать Парковочный талон. Если лимит бесплатного времени не превышен или Услуга Платной парковки оплачена, после полного открытия шлагбаума выезжайте с территории Платной парковки."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47" + " " + "py-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
                                                className: "jsx-3162d9804c822d47",
                                                children: "Вниманию Пользователей Платной парковки:"
                                            })
                                        }),
                                        " ",
                                        "В случае возникновения каких-либо затруднений с выездом с территории Платной парковки (не считывается Парковочный талон, не поднимается шлагбаум) просим связаться со службой поддержки Организатора парковки, нажав на кнопку переговорного устройства, которая находится на лицевой панели выездной стойки либо позвонив по телефону: (861) 213 47 07."
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        "20.\xa0",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Утеря / порча / повреждение "
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Парковочного талона:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "21. Пользователь Платной парковки обязан сохранять Парковочный талон до выезда с Платной парковки."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "jsx-3162d9804c822d47",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: [
                                                "В случае утери /порчи / повреждения Парковочного талона Пользователь Платной парковки обязан возместить Организатору парковки причиненный ущерб в размере",
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                    className: "jsx-3162d9804c822d47",
                                                    children: "1\xa0000,00 (Одна тысяча) рублей"
                                                }),
                                                " сверх стоимости оказанной Услуги. Уплаченная Пользователем Платной парковки сумма за утерю и порчу Парковочного талона не возвращается."
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Выезд транспортного средства Пользователя Платной парковки до момента замены Парковочного талона невозможен. Замена Парковочных талонов производится Организатором парковки круглосуточно. Для замены Парковочного талона просим связаться со службой поддержки Организатора парковки, нажав на кнопку переговорного устройства Паркомата либо позвонив по телефону: (861) 213 47 07."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-3162d9804c822d47",
                                            children: "Организатор парковки не несет ответственности за убытки, которые могут причинены Пользователю Платной парковки в результате задержки транспортного средства на Платной парковке по причине утери /порчи / повреждения Парковочного талона."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "22. В случае совершения дорожно-транспортного происшествия на Платной парковке или непосредственно возле въезда на нее Пользователь Платной парковки обязан выполнить требования Правил дорожного движения Российской Федерации, а кроме того, немедленно известить Организатора парковки по телефону технической поддержки: (861) 213 47 07 и обеспечить скорейшее восстановление беспрепятственного движения транспортных средств."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47",
                                    children: "23. Организатор парковки вправе перекрывать движение и (или) прекращать доступ к Платной парковке, отдельным ее частям в случае проведения каких-либо мероприятий или иной необходимости, а также устанавливать места, за пределами которых стоянка транспортных средств определенных лиц или категорий запрещена либо в которых разрешена стоянка только транспортных средств определенных лиц или категорий (например, владельцев парковочных абонементов)."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "jsx-3162d9804c822d47" + " " + "pt-10",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        className: "jsx-3162d9804c822d47",
                                        children: "* Не является публичной офертой. Организатор парковки вправе по своему усмотрению без объяснения причин отказать какому-либо лицу в предоставлении услуг Платной парковки."
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Parking);


/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 5065:
/***/ ((module) => {

module.exports = require("react-icons/sl");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,61,668], () => (__webpack_exec__(7554)));
module.exports = __webpack_exports__;

})();