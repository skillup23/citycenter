"use strict";
(() => {
var exports = {};
exports.id = 695;
exports.ids = [695];
exports.modules = {

/***/ 5818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ events)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Layout.js + 8 modules
var Layout = __webpack_require__(3668);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/SliderMain.js
var SliderMain = __webpack_require__(6561);
// EXTERNAL MODULE: ./public/site_img/текст-2.png
var _2 = __webpack_require__(9668);
// EXTERNAL MODULE: ./public/site_img/лого-монитор.png
var _ = __webpack_require__(384);
// EXTERNAL MODULE: ./public/site_img/лого-монитор-2.png
var site_img_2 = __webpack_require__(9731);
;// CONCATENATED MODULE: ./public/events_img/смотреть-фотоотчет.png
/* harmony default export */ const events_img_ = ({"src":"/_next/static/media/смотреть-фотоотчет.803260ec.png","height":46,"width":428,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAADFBMVEV8fHuEhIOcnJuNjYws07TmAAAACXBIWXMAABJ0AAASdAHeZh94AAAAEUlEQVR4nGNgYGBiZmBgZAQAACcACJivwR8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./public/events_img/70256957.jpg
/* harmony default export */ const _70256957 = ({"src":"/_next/static/media/70256957.7c1ba74d.jpg","height":853,"width":1185,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAf/xAAeEAABBAIDAQAAAAAAAAAAAAABAAIDEQQFEiFBkf/EABQBAQAAAAAAAAAAAAAAAAAAAAT/xAAWEQADAAAAAAAAAAAAAAAAAAAAAzH/2gAMAwEAAhEDEQA/AJvjbWPH1xxWxATB7OEoYLDe7BPt2PiIiO2iVQ//2Q==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/events_img/69458247.jpg
/* harmony default export */ const _69458247 = ({"src":"/_next/static/media/69458247.398f4801.jpg","height":853,"width":1186,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAgEAABBQAABwAAAAAAAAAAAAABAAIDBRIEESEiMUFR/8QAFQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAXEQEBAQEAAAAAAAAAAAAAAAABABEh/9oADAMBAAIRAxEAPwCW4W2rIa5jIqwGZ8YhlfrDXZHacg8vPU/faIiEMK97f//Z","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/events_img/event_prev3.jpg
/* harmony default export */ const event_prev3 = ({"src":"/_next/static/media/event_prev3.3b339461.jpg","height":503,"width":700,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAf/xAAeEAABAwQDAAAAAAAAAAAAAAABAAMEAgURExIhMf/EABUBAQEAAAAAAAAAAAAAAAAAAAID/8QAFhEBAQEAAAAAAAAAAAAAAAAAABEB/9oADAMBAAIRAxEAPwCYzL7JmwGITjTGtk8qTrzVkjHp7RERil1//9k=","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: ./public/data/data.js
var data = __webpack_require__(5743);
;// CONCATENATED MODULE: ./pages/events/index.js















function Events() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        title: "События",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "relative",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(SliderMain/* default */.Z, {
                        data: data/* sliderCenter */.KI,
                        dots: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: _2/* default */.Z,
                        alt: "slide1",
                        width: "0",
                        height: "0",
                        sizes: "100%",
                        className: "absolute top-6 right-0 w-1/12"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mt-20",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container mx-auto pr-5 flex flex-row gap-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pl-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-12 w-1/2 mb-12 items-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: _/* default */.Z,
                                        alt: "Лого Монитор",
                                        width: "200",
                                        height: "0",
                                        sizes: "100%",
                                        className: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: site_img_2/* default */.Z,
                                        alt: "Лого Монитор Делюкс",
                                        width: "150",
                                        height: "0",
                                        sizes: "100%",
                                        className: ""
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mb-8 text-xl",
                                children: "\xabМОНИТОР Сити de Luxe\xbb — кинотеатр нового уровня, соответствующий актуальным трендам мирового кинопоказа и современного дизайна. Кинотеатр оборудован высококачественной кинопроекционной системой Sony Digital.Cinema 4K с функцией показа максимально чёткого изображения."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mb-8 text-xl",
                                children: "В двух комфортных залах на 62 и 64 места установлены удобные кресла с выдвижными столиками, огромным личным пространством и большим расстоянием между рядами. Все кресла имеют выдвижную слайдер-систему. Последний ряд оборудован раскладывающимися креслами-реклайнерами с подставкой для ног, которые можно привести в полностью горизонтальное положение."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mb-8 text-xl",
                                children: "Также у нас вы можете заказать еду из ресторана прямо в кинозал. Официант принесёт заказ и разместит его на столике у кресла."
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mt-10",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container mx-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pr-5 flex flex-row",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex flex-col pl-3 w-1/3",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-5xl",
                                                children: "КИНОТЕАТР"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-2xl",
                                                children: "УЛ. ИНДУСТРИАЛЬНАЯ, 2, ЭТАЖ 2"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "tel:89676513344",
                                                className: "text-2xl",
                                                children: "+7 967 651 33 44"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://www.instagram.com/kinomonitor/",
                                                target: "_blank",
                                                className: "text-2xl",
                                                children: "@KINOMONITOR"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-2xl",
                                                children: "ЕЖЕДНЕВНО, 10:00-02:00"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex flex-col pl-3",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-5xl",
                                                children: "ОТДЕЛЫ РЕКЛАМЫ"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-2xl",
                                                children: "УЛ. ИНДУСТРИАЛЬНАЯ, 2, ЭТАЖ 2"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "tel:88612134847",
                                                className: "text-2xl",
                                                children: "8 861 213-48-47"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "tel:88612134842",
                                                className: "text-2xl",
                                                children: "8 (861) 213-48-42"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex flex-row w-fill items-center mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillHexagonFill, {
                                                className: "text-3xl mr-5 text-[#1e191a]"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "mailto:E.PRITOTSKAYA@CITICENTER.RU",
                                                className: "text-2xl",
                                                children: "E.PRITOTSKAYA@CITICENTER.RU"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "my-20",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto flex gap-6",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-6 w-1/3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://geo.pro/reportage/509063-master-klass-i-chapurin-tendentsii-mody-2019/?sphrase_id=394720",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: _70256957,
                                        alt: "Событие 1",
                                        width: "100%",
                                        sizes: "100%",
                                        className: "w-full"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "text-2xl",
                                    children: "МАСТЕР-КЛАСС I.CHAPURIN \xabТЕНДЕНЦИИ МОДЫ 2019\xbb"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://geo.pro/reportage/509063-master-klass-i-chapurin-tendentsii-mody-2019/?sphrase_id=394720",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: events_img_,
                                        alt: "Событие 1",
                                        width: 300,
                                        sizes: "100%",
                                        className: "hover:scale-95 ease-in duration-200"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-6 w-1/3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://geo.pro/reportage/523593-fashion-cinema-de-luxe/?sphrase_id=394720",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: _69458247,
                                        alt: "Событие 1",
                                        width: "100%",
                                        sizes: "100%",
                                        className: "w-full"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "text-2xl",
                                    children: "#WEEKEND С НАДЕЖДОЙ МЕЙХЕР"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://geo.pro/reportage/523593-fashion-cinema-de-luxe/?sphrase_id=394720",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: events_img_,
                                        alt: "Событие 1",
                                        width: 300,
                                        sizes: "100%",
                                        className: "hover:scale-95 ease-in duration-200"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-6 w-1/3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://geo.pro/reportage/522435-fashion-cinema-de-luxe/?sphrase_id=394720",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: event_prev3,
                                        alt: "Событие 1",
                                        width: "100%",
                                        sizes: "100%",
                                        className: "w-full"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "text-2xl",
                                    children: "МАСТЕР-КЛАСС I.CHAPURIN \xabТЕНДЕНЦИИ МОДЫ 2019\xbb"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://geo.pro/reportage/522435-fashion-cinema-de-luxe/?sphrase_id=394720",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: events_img_,
                                        alt: "Событие 1",
                                        width: 300,
                                        sizes: "100%",
                                        className: "hover:scale-95 ease-in duration-200"
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const events = (Events);


/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 5065:
/***/ ((module) => {

module.exports = require("react-icons/sl");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,61,668,45], () => (__webpack_exec__(5818)));
module.exports = __webpack_exports__;

})();